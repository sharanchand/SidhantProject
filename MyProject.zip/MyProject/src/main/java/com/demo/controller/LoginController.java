package com.demo.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.demo.dao.LoginDao;
import com.demo.model.Login;


@RestController
public class LoginController {


	LoginDao loginService=new LoginDao();
	
	@RequestMapping(value="validation/{userId}/{pass}",method=RequestMethod.POST)//,headers="Accept=application/json")
	public String validation(@PathVariable String userId,@PathVariable String pass){
		Login login=new Login();
		login.setLoginId(userId);
		login.setPassword(pass);
		String valid=loginService.validate(login);
		System.out.println(valid);
		return valid;
	}
}
