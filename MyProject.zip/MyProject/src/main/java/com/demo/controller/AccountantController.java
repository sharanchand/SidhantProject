package com.demo.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.demo.dao.LoginDao;
import com.demo.model.AccountantDetails;
import com.demo.model.ViewStudent;

@RestController
public class AccountantController {

	LoginDao AccountantService=new LoginDao();
	@RequestMapping(value="registerAccountant/{name}/{email}/{address}/{mobno}/{accid}/{pass}",method=RequestMethod.POST)//,headers="Accept=application/json")
	public void register(@PathVariable String name,@PathVariable String email,@PathVariable String address,@PathVariable int mobno,@PathVariable int accid,@PathVariable String pass) throws SQLException{
		AccountantDetails acc= new AccountantDetails();
		System.out.println("IN Controller");
		acc.setName(name);
		acc.setEmail(email);
		acc.setAddress(address);
		acc.setMobile(mobno);
		acc.setAccId(accid);
		acc.setPassword(pass);
		System.out.println(acc.getName());
		AccountantService.register(acc);		
		System.out.println(acc.getName());
		
}
	
	
	
	
	@RequestMapping(value="editAccountant/{accid}/{name}/{email}/{address}/{mobno}/{pass}",method=RequestMethod.POST)
	public void edit(@PathVariable String name,@PathVariable String email,@PathVariable String address,@PathVariable long mobno,@PathVariable int accid,@PathVariable String pass) throws SQLException{
		AccountantDetails acc= new AccountantDetails();
		System.out.println("IN EDIT ACCOUNTANT Controller");
		acc.setName(name);
		acc.setEmail(email);
		acc.setAddress(address);
		acc.setMobile(mobno);
		acc.setAccId(accid);
		acc.setPassword(pass);
		System.out.println(acc.getName());
		AccountantService.edit_accountant(acc);		
		System.out.println(acc.getName());
		
}
	
	@RequestMapping(value="DeleteAccountant/{accId}/{name}",method=RequestMethod.POST)
	public void deleteAccountant(@PathVariable int accId,@PathVariable String name){
		System.out.println("In Accountant DELETE Controller");
		AccountantDetails ad=new AccountantDetails();
		ad.setAccId(accId);
		ad.setName(name);
		AccountantService.deleteAccountant(ad);
}
}