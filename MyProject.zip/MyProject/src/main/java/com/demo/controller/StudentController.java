package com.demo.controller;

import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.demo.dao.LoginDao;
import com.demo.model.CourseDetails;
import com.demo.model.FeeDetails;
import com.demo.model.StudentDetails;
import com.demo.model.ViewStudent;


@RestController
public class StudentController {
	
	LoginDao StudentService=new LoginDao();
	static int c_id=4;
	static int f_id=4;
	
	@RequestMapping(value="registerStudent/{name}/{email}/{address}/{mobno}/{rollno}/{cou}/{totfee}/{paid}",method=RequestMethod.POST)//,headers="Accept=application/json")
	public void register(@PathVariable String name,@PathVariable String email,@PathVariable String address,@PathVariable int mobno,@PathVariable int rollno,@PathVariable String cou,@PathVariable int totfee,@PathVariable int paid){
		System.out.println("In Student Controller");
		StudentDetails stud= new StudentDetails();
		CourseDetails cour=new CourseDetails();
		FeeDetails feed=new FeeDetails();
		stud.setName(name);
		stud.setEmail(email);
		stud.setAddress(address);
		stud.setMobile(mobno);
		stud.setRollNo(rollno);
		cour.setRollNo(rollno);
		cour.setCourse(cou);
		int cid=++c_id;
		int fid=++f_id;
		cour.setcId(cid);
		feed.setfId(fid);
		feed.setRollNo(rollno);
		feed.setFee(totfee);
		feed.setPaid(paid);
		int due=totfee-paid;
		System.out.println(due);
		feed.setDue(due);
		StudentService.registerStudent(stud,cour,feed);
		
		System.out.println(stud.getName());
		
}

	@RequestMapping(value="editStudent/{rollno}/{name}/{address}/{email}/{mobile}/{cou}/{fee}/{paid}",method=RequestMethod.POST)
	public void edit(@PathVariable int rollno,@PathVariable String name,@PathVariable String address,@PathVariable String email,@PathVariable long mobile,@PathVariable String cou,@PathVariable int fee,@PathVariable int paid){
		System.out.println("In Student EDIT Controller");
		ViewStudent vs=new ViewStudent();
		vs.setRollNo(rollno);
		vs.setName(name);
		vs.setAddress(address);
		vs.setEmail(email);
		vs.setMobile(mobile);
		vs.setCourse(cou);
		vs.setFee(fee);
		vs.setPaid(paid);
		int due=fee-paid;
		vs.setDue(due);
		StudentService.editStudent(vs);
		
}
	@RequestMapping(value="DeleteStudent/{rollNo}",method=RequestMethod.POST)
	public void deleteStudent(@PathVariable int rollNo){
		System.out.println("In Student DELETE Controller");
		ViewStudent vs=new ViewStudent();
		vs.setRollNo(rollNo);
		StudentService.deleteStudent(vs);

}
}
