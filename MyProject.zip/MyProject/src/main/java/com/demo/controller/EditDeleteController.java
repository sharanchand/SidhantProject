package com.demo.controller;

import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.demo.dao.LoginDao;
import com.demo.model.AccountantDetails;
import com.demo.model.ViewStudent;

@RestController
public class EditDeleteController {

	LoginDao ViewService=new LoginDao();
	@RequestMapping(value="EditDeleteStudent",method=RequestMethod.GET)
	public List<ViewStudent> ViewStudent()
	{
		List<ViewStudent> studview;
		
		studview=ViewService.Student_display();
		
		return studview;
		
	}
	
	@RequestMapping(value="EditDeleteAccountant",method=RequestMethod.GET)
	public List<AccountantDetails> ViewAccoutant()
	{
		List<AccountantDetails> accview;
		
		accview=ViewService.Accountant_display1();
		
		return accview;
		
	}
	
}
