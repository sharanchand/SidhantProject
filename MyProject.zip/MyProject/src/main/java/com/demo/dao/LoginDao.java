package com.demo.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.demo.model.AccountantDetails;
import com.demo.model.CourseDetails;
import com.demo.model.FeeDetails;
import com.demo.model.Login;
import com.demo.model.StudentDetails;
import com.demo.model.ViewStudent;

import oracle.jdbc.driver.OracleTypes;

@Service
public class LoginDao {

	private CallableStatement cst;
	private Connection connection;
	public LoginDao(){
		connection = DBUtil.getMyConnection();
	}
	
	//Login Class to Validate and retrieve the role 
	public String validate(Login login) {
		String role = " ";
		try {
			cst = connection.prepareCall("{call retreivepass_258(?,?,?)}");
			cst.setString(1, login.getLoginId());
			cst.setString(2, login.getPassword());
			
			cst.registerOutParameter(3, java.sql.Types.CHAR,role);
			cst.execute();
				
			role=cst.getString(3);
			login.setRole(role.trim());
		
		}
		catch (SQLException e) {
			e.printStackTrace();
			
		}
	
		System.out.println("role:" + role);
			return login.getRole();
		
	}
	
	//Register New Accountant
	public void register(AccountantDetails acc)  {
		System.out.println("Almost in Dao");
		try {
			cst = connection.prepareCall("{call insert_accountant_details_258(?,?,?,?,?,?)}");
			System.out.println("In Dao");
			cst.setString(1, acc.getName());
			cst.setString(2, acc.getEmail());
			cst.setString(3, acc.getAddress());
			cst.setLong(4, acc.getMobile());
			cst.setInt(5, acc.getAccId());
			cst.setString(6, acc.getPassword());
			cst.execute();
			System.out.println("Accountant Added");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

}
	// Register New Student
	public void registerStudent(StudentDetails stud,CourseDetails course,FeeDetails fee) {
		System.out.println("Almost in Dao");
		try {
			CallableStatement cst = connection.prepareCall("{call insert_student_details_258(?,?,?,?,?)}");
			System.out.println("In Student Dao");
			cst.setInt(1,stud.getRollNo() );
			cst.setString(2, stud.getName());
			cst.setString(3, stud.getAddress());
			cst.setString(4, stud.getEmail());
			cst.setInt(5, stud.getMobile());
			cst.execute();
			System.out.println("Student Added");
			
			CallableStatement cst1=connection.prepareCall("{call insert_course_details_258(?,?,?)}");
			System.out.println("In course Dao");
			cst1.setInt(1,course.getRollNo());
			cst1.setInt(2,course.getcId());
			cst1.setString(3,course.getCourse());
			cst1.execute();
			System.out.println("Exiting course dao");
			
			CallableStatement cst2=connection.prepareCall("{call insert_fee_details_258(?,?,?,?,?)}");
			System.out.println("In fee Dao");
			cst2.setInt(1,fee.getRollNo());
			cst2.setInt(2,fee.getfId());
			cst2.setInt(3,fee.getFee());
			cst2.setInt(4,fee.getPaid());
			cst2.setInt(5,fee.getDue());
			cst2.execute();
			System.out.println("Exiting Fee Dao");
	}catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
}
	//View the details of the StudentDetails,AccountantDetails,FeeDetails Class
	public List<ViewStudent> Student_display()
	{
		List<ViewStudent> studview=new ArrayList<ViewStudent>();
		try {
			CallableStatement cst=connection.prepareCall("{call  view_student_details_258(?)}");
			cst.registerOutParameter(1,OracleTypes.CURSOR);
			cst.execute();		
			ResultSet rs=(ResultSet) cst.getObject(1);
			
			while(rs.next())
			{
				ViewStudent viewstud=new ViewStudent();
				
				viewstud.setRollNo(rs.getInt("rollno"));
				viewstud.setName(rs.getString("name"));
				viewstud.setAddress(rs.getString("address"));
				viewstud.setEmail(rs.getString("email"));
				viewstud.setMobile(rs.getLong("mobile"));
				viewstud.setCourse(rs.getString("course"));
				viewstud.setFee(rs.getInt("fee"));
				viewstud.setPaid(rs.getInt("paid"));
				viewstud.setDue(rs.getInt("due"));
				
				studview.add(viewstud);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return studview;
	}
	//Edit Student Details
	public void editStudent(ViewStudent vs)
	{
		try {
			CallableStatement cst = connection.prepareCall("{call edit_student_details_258(?,?,?,?,?,?,?,?,?)}");
			System.out.println("In Student Dao");
			cst.setInt(1,vs.getRollNo() );
			cst.setString(2, vs.getName());
			cst.setString(3, vs.getAddress());
			cst.setString(4, vs.getEmail());
			cst.setLong(5, vs.getMobile());
			cst.setString(6,vs.getCourse());
			cst.setInt(7,vs.getFee());
			cst.setInt(8,vs.getPaid());
			cst.setInt(9,vs.getDue());
			cst.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("After execution in Student Dao");
		
		
	}
	// Delete Student Details
	public void deleteStudent(ViewStudent vs)
	{
		try {
			CallableStatement cst = connection.prepareCall("{call delete_student_details_258(?)}");
			System.out.println("In Student Delete Dao");
			cst.setInt(1,vs.getRollNo());
			cst.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Exiting Delete Dao");
	}
	//Display Accountant Details
	public List<AccountantDetails> Accountant_display()
	{
		List<AccountantDetails> accview=new ArrayList<AccountantDetails>();
		try {
			CallableStatement cst=connection.prepareCall("{call  view_accountant_details_258(?)}");
			cst.registerOutParameter(1,OracleTypes.CURSOR);
			cst.execute();		
			ResultSet rs=(ResultSet) cst.getObject(1);
			
			while(rs.next())
			{
				AccountantDetails viewacc=new AccountantDetails();
				
				viewacc.setAccId(rs.getInt("acc_id"));
				viewacc.setName(rs.getString("name"));
				viewacc.setAddress(rs.getString("address"));
				viewacc.setEmail(rs.getString("email"));
				viewacc.setMobile(rs.getLong("mobile"));
								
				accview.add(viewacc);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return accview;
	}
	//Show Accountant Details
	public List<AccountantDetails> Accountant_display1()
	{
		List<AccountantDetails> accview=new ArrayList<AccountantDetails>();
		try {
			CallableStatement cst=connection.prepareCall("{call  view_Accountant_details_258(?)}");
			cst.registerOutParameter(1,OracleTypes.CURSOR);
			cst.execute();		
			ResultSet rs=(ResultSet) cst.getObject(1);
			
			while(rs.next())
			{
				AccountantDetails viewacc=new AccountantDetails();
				
				viewacc.setAccId(rs.getInt("acc_id"));
				viewacc.setName(rs.getString("name"));
				viewacc.setAddress(rs.getString("address"));
				viewacc.setEmail(rs.getString("email"));
				viewacc.setMobile(rs.getLong("mobile"));
				viewacc.setPassword(rs.getString("password"));
				
				accview.add(viewacc);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return accview;
	}
	
	public void edit_accountant(AccountantDetails acc)  {
		System.out.println("Almost in Dao");
		try {
			cst = connection.prepareCall("{call  edit_accountant_details_258(?,?,?,?,?,?)}");
			System.out.println("In Edit Dao");
			cst.setInt(1, acc.getAccId());
			cst.setString(2, acc.getName());
			cst.setString(3, acc.getAddress());
			cst.setString(4, acc.getEmail());
			cst.setLong(5, acc.getMobile());
			cst.setString(6, acc.getPassword());
			cst.execute();
			System.out.println("Accountant Edited");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
	
	public void deleteAccountant(AccountantDetails vs)
	{
		try {
			CallableStatement cst = connection.prepareCall("{call delete_accountant_details_258(?,?)}");
			System.out.println("In Student Delete Dao");
			cst.setInt(1,vs.getAccId());
			cst.setString(2,vs.getName());
			cst.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Exiting Delete Dao");
	}
}
