package com.demo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.annotation.Resource;

public class DBUtil {
	private static Connection connection=null;
	public static Connection getMyConnection()
	{
		if(connection!=null)
			return connection;
		else
		{
			try{
				String url="jdbc:oracle:thin:@10.232.71.29:1521:INATP02";
				 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
				 connection=DriverManager.getConnection(url,"Shobana","Shobana");
				 
			}catch(SQLException e)
			{
				e.printStackTrace();
			}
			return connection;
		}
	}

}
