package com.demo.model;

import org.springframework.stereotype.Component;

@Component
public class ViewStudent {

	private int rollNo;
	private String name;
	private String address;
	private String email;
	private long mobile;
	private String course;
	private int fee;
	private int paid;
	private int due;
	
	public ViewStudent(int rollNo, String name, String address, String email, long mobile, String course, int fee,
			int paid, int due) {
		super();
		this.rollNo = rollNo;
		this.name = name;
		this.address = address;
		this.email = email;
		this.mobile = mobile;
		this.course = course;
		this.fee = fee;
		this.paid = paid;
		this.due = due;
	}

	public ViewStudent() {
		super();
	}

	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public int getFee() {
		return fee;
	}

	public void setFee(int fee) {
		this.fee = fee;
	}

	public int getPaid() {
		return paid;
	}

	public void setPaid(int paid) {
		this.paid = paid;
	}

	public int getDue() {
		return due;
	}

	public void setDue(int due) {
		this.due = due;
	}
	
	
	
	
}
