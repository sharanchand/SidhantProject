                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        package com.demo.model;

import org.springframework.stereotype.Component;

@Component
public class StudentDetails {

	private int rollNo;
	private String name;
	private String address;
	private String email;
	private int mobile;
	
	public int getRollNo() {
		return rollNo;
	}
	
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public int getMobile() {
		return mobile;
	}
	
	public void setMobile(int mobno) {
		this.mobile = mobno;
	}

	public StudentDetails(int rollNo, String name, String address, String email, int mobile) {
		super();
		this.rollNo = rollNo;
		this.name = name;
		this.address = address;
		this.email = email;
		this.mobile = mobile;
	}

	public StudentDetails() {
		super();
	}
	
	
	
	
}
