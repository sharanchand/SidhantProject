package com.demo.model;

public class FeeDetails {

	private int rollNo;
	private int fId;
	private int fee;
	private int paid;
	private int due;
	
	public int getRollNo() {
		return rollNo;
	}
	
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	
	public int getfId() {
		return fId;
	}
	
	public void setfId(int fId) {
		this.fId = fId;
	}
	
	public int getFee() {
		return fee;
	}
	
	public void setFee(int totfee) {
		this.fee = totfee;
	}
	
	public int getPaid() {
		return paid;
	}
	
	public void setPaid(int paid2) {
		this.paid = paid2;
	}
	
	public int getDue() {
		return due;
	}
	
	public void setDue(int due) {
		this.due = due;
	}

	public FeeDetails(int rollNo, int fId, int fee, int paid, int due) {
		super();
		this.rollNo = rollNo;
		this.fId = fId;
		this.fee = fee;
		this.paid = paid;
		this.due = due;
	}

	public FeeDetails() {
		super();
	}
	
	
}
