package com.demo.model;

public class CourseDetails {

	private int rollNo;
	private int cId;
	private String course;
	
	public int getRollNo() {
		return rollNo;
	}
	
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	
	public int getcId() {
		return cId;
	}
	
	public void setcId(int cId) {
		this.cId = cId;
	}
	
	public String getCourse() {
		return course;
	}
	
	public void setCourse(String course) {
		this.course = course;
	}

	public CourseDetails(int rollNo, int cId, String course) {
		super();
		this.rollNo = rollNo;
		this.cId = cId;
		this.course = course;
	}

	public CourseDetails() {
		super();
	}
	
		
}
